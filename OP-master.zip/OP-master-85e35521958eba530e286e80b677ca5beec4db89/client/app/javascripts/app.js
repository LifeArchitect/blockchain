// Import the page's CSS. Webpack will know what to do with it.
import '../stylesheets/app.css';
// Import libraries we need.

window.make_flight = function() {
  var flightNo = $("#flightNo").val();
  var tailNo = $("#tailNo").val();
  var origin = $("#origin").val();
  var destination = $("#destination").val();
  var takeOffTime = $("#takeOffTime").val();
  var landingTime = $("#landingTime").val();

  $.post("/api/operator/", 
  {
    "flightNo": parseInt(flightNo),
    "tailNo": parseInt(tailNo),
    "origin": origin,
    "destination": destination,
    "takeOffTime": takeOffTime,
    "landingTime": landingTime,
  });
}

window.search_part_history = function() {
  var id = $("#partIDsearch").val();
  var table = $("#partHistory");
  table.html("<thead class=\"thead-default\"><th>Part Transactions</th></thead><tbody>");
  
  $.get("/api/search/"+id, function(result) {
    result.forEach(function(transaction) {
      var row = "<tr>";
      row += "<td><p><strong>HASH:</strong> " + transaction.hash + "</p>";
      row += "<p><strong>Description:</strong> " + transaction.description + "</p>";
      row += "<p><strong>Time of transaction:</strong> " + transaction.time + "</p>";
      row += "</td></tr>";
      table.append(row);
    });
  });
  table.append("</tbody>");
}

window.search_flight_history = function() {
  var id = $("#tailNosearch").val();
  var table = $("#flightHistory");
  table.html("<thead class=\"thead-default\"><th>Flight Transactions</th></thead><tbody>");
  
  $.get("/api/operator/search/"+id, function(result) {
    result.forEach(function(transaction) {
      var row = "<tr>";
      row += "<td><p><strong>HASH:</strong> " + transaction.hash + "</p>";
      row += "<p><strong>Flight No.:</strong> " + parseInt(transaction.flightNo, 16) + "</p>";
      row += "<p><strong>Origin:</strong> " + transaction.origin + "</p>";
      row += "<p><strong>Destination:</strong> " + transaction.destination + "</p>";
      row += "<p><strong>Takeoff Time:</strong> " + transaction.takeOffTime + "</p>";
      row += "<p><strong>Landing Time:</strong> " + transaction.landingTime + "</p>";
      row += "</td></tr>";
      table.append(row);
    });
  });
  table.append("</tbody>");
}

window.search_flight_history_db = function() {
  var id = $("#tailNoSearchDb").val();
  var table = $("#flightHistoryDb");
  table.html("<thead class=\"thead-default\"><th>Database Flights</th></thead><tbody>");
  
  $.get("/api/db/search/"+id, function(result) {
    result.forEach(function(flight) {
      var row = "<tr>";
      row += "<td><p><strong>Flight No.:</strong> " + parseInt(flight.flightNo, 16) + "</p>";
      row += "<p><strong>Origin:</strong> " + flight.origin + "</p>";
      row += "<p><strong>Destination:</strong> " + flight.destination + "</p>";
      row += "<p><strong>Takeoff Time:</strong> " + flight.takeOffTime + "</p>";
      row += "<p><strong>Landing Time:</strong> " + flight.landingTime + "</p>";
      row += "</td></tr>";
      table.append(row);
    });
  });
  table.append("</tbody>");
}

$( document ).ready(function() {
  $("#takeOffTime").val(new Date().toJSON().slice(0,16));
  $("#landingTime").val(new Date().toJSON().slice(0,16));
});
