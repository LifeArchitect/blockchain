/**
 * Service layer for agents
 */
'use strict';

var _ = require('lodash');
var when = require('when');

var flightDao = require('../dao/flight.dao');

var _this = this;

// Import libraries we need.
var Web3 = require('web3');
var contract = require('truffle-contract');
var config = require('../config/environment');

// Decode the blockchain hash into input params
const InputDataDecoder = require('ethereum-input-data-decoder');

var supply_artifacts = require('../contracts/Supply.json');
var Supply = contract(supply_artifacts);
// abi definition necessary for the decoding
var supply_abi = supply_artifacts.abi;

const decoder = new InputDataDecoder(supply_abi);

var web3 = new Web3(new Web3.providers.HttpProvider(config.blockchain));

var contract_instance;
Supply.setProvider(web3.currentProvider);
Supply.deployed().then(function (contractInstance) {
    contract_instance = contractInstance;
});

exports.createFlightTransaction = function(transaction) {
    var defer = when.defer();
    console.log(transaction);
    var date = Date.now().toString();
    var flightNo = transaction.flightNo;
    var tailNo = transaction.tailNo;
    var origin = transaction.origin;
    var destination = transaction.destination;
    var takeOffTime = transaction.takeOffTime;
    var landingTime = transaction.landingTime;
    contract_instance.makeFlight(flightNo, tailNo, origin, destination, takeOffTime, landingTime, {gas: 1400000, from: web3.eth.accounts[0]}).then(function (trans) {
        contract_instance.addFlightHistory(tailNo, trans.tx, {gas: 140000, from: web3.eth.accounts[0]});
        defer.resolve();
        flightDao.createFlightPromise(transaction);
    }, function(err) {
        defer.reject(err);
    });
    return defer.promise;
};

exports.searchFlightHistoryByTailNoDb = function searchPartHistoryByTailNoDb(tailNo) {

  console.log(tailNo);
  return when(flightDao.findFlightsPromiseByTailNo(tailNo));
  
}

exports.searchFlightHistoryByTailNo = function searchFlightHistoryByTailNo(tail_no) {
    var defer = when.defer();
    contract_instance.searchFlightHistory(tail_no, {gas: 1400000, from: web3.eth.accounts[0]}).then(function(results) {
        var promise = [];
        results.forEach(function(transaction) {
            var hash = transaction;
            var data = web3.eth.getTransaction(transaction).input;
            var result = decoder.decodeData(data).inputs;
            console.log(result);
            var flightNo = result[0]
            var origin = result[2];
            var destination = result[3];
            var takeOffTime = result[4];
            var landingTime = result[5];

            promise.push({
                hash:hash,
                flightNo:flightNo,
                origin:origin,
                destination:destination,
                takeOffTime:takeOffTime,
                landingTime:landingTime});
        });
        defer.resolve(promise);
    }, function(err) {
        defer.reject(err);
    });
    return defer.promise;
}
