'use strict';

// Production specific configuration
// =================================
module.exports = {
  // MongoDB connection options
  mongo: {
    uri: 'mongodb://sia:password@ds053166.mlab.com:53166/shioksiadb'
  },

  seedDB: false
};