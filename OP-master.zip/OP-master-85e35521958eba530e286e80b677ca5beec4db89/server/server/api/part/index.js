'use strict';

var express = require('express');
var controller = require('./part.controller');

var router = express.Router();

// route middleware that will happen on every request

router.get('/', controller.findAll);
router.get('/:id', controller.findById);
router.get('/import', controller.import);

module.exports = router;
