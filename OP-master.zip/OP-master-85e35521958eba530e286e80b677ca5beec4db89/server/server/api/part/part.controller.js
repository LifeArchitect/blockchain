'use strict';

var partService = require('../../service/part.service.js');

/**
 * Get list of parts
 * GET /parts
 *
 * @param req
 * @param res
 */
exports.findAll = function (req, res) {
    partService.findAll()
        .then(function (parts) {
            return res.json(200, parts);
        }, function (err) {
            return handleError(res, err);
        });
};

exports.findById = function (req, res) {
    partService.findById()
        .then(function (parts) {
            return res.json(200, parts);
        }, function (err) {
            return handleError(res, err);
        });
};

exports.import = function (req, res) {
    partService.import()
        .then(function (parts) {
            return res.json(200, parts);
        }, function (err) {
            return handleError(res, err);
        });
};
