'use strict';

var mongoose = require('mongoose');
var _ = require('lodash');
require("../models/part.model.js");
var Part = mongoose.model('Part')
var Part = require('./../models/part.model.js');
var _this = this;

exports.findPartsPromise = function () {
    return Part.find().exec();
}

exports.findPartByIdPromise = function findPartByIdPromise(id) {
    return Part.findById(id).exec();
}

exports.importPromise = function importPromise(){
  Part.create(
  {"name": "Wheel", "partNo": "1", "serialNo": "123"},
  {"name": "Wheel", "partNo": "2", "serialNo": "124"},
  {"name": "Wheel", "partNo": "3", "serialNo": "125"}
  )
}
