'use strict';

var express = require('express');
var controller = require('./flight_transaction.controller');

var router = express.Router();

router.post('/', controller.create);
router.get('/search/:id', controller.search);
console.log("api...")
router.get('/:id', controller.search_db);


module.exports = router;
