'use strict';

var mongoose = require('mongoose'), 
    Schema = mongoose.Schema;

var FlightSchema = new Schema({
    flightNo: Number,
    tailNo: Number,
    origin: String,
    destination: String,
    takeOfTime: Date,
    landingTime: Date
});

module.exports = mongoose.model('Flight', FlightSchema);

  