'use strict';

var mongoose = require('mongoose');
var _ = require('lodash');

var Flight = require('./../models/flight.model.js');

var _this = this;

exports.findFlightsPromiseByTailNo = function (tailNo) {
    console.log("finding flights of tailNo: " + tailNo);
    var flights = Flight.find({TailNo:tailNo}).exec();
    console.log(flights);
    return flights;
};

exports.createFlightPromise = function (flight) {
    
    console.log("creating flight promise..." + flight);
    Flight.create(flight); 
    
};