/**
 * Main application routes
 */

'use strict';

var express = require('express')
var errors = require('./components/errors');
var config = require('./config/environment');
var path = require('path');
//var cors = require('./auth/middleware/cors.js');

module.exports = function (app) {

//    app.use(cors);

    // Insert routes below
    app.use('/api/agents', require('./api/agent'));
    app.use('/api/operator', require('./api/flight_transaction'));
    app.use('/api/search', require('./api/search_part_history'));
    app.use('/api/db/search', require('./api/flight_transaction'));

    app.use('/', express.static(path.join(config.root, 'client', 'app', 'sb-admin')));

    // All undefined asset or api routes should return a 404
    app.route('/:url(api|auth|components|app|bower_components|assets)/*')
        .get(errors[404]);

    // All other routes should redirect to the index.html
    // app.route('/')
    //     .get(function (req, res) {
    //         res.sendfile(app.get('appPath') + '/app/index.html');
    //     });
    // app.route('/*')
    //     .get(errors[404]);
};
