var mongoose = require('mongoose'),
Schema = mongoose.Schema;

var PartSchema = new Schema({
  name: String,
  partNo: Number,
  serialNo: Number
});

mongoose.model('Part', PartSchema);
