/**
 * Service layer for parts
 */
'use strict';

var _ = require('lodash');
var when = require('when');
var partDao = require('../dao/part.dao');
var _this = this;


exports.findAgents = function findAgents() {
    return when(partDao.findPartPromise());
}

exports.findAll = function findAll() {
    return when(partDao.findPartByIdPromise());
}

exports.findAll = function findAll() {
    return when(partDao.importPromise());
}
