'use strict';

var transactionService = require('../../service/flight_transaction.service.js');

exports.create = function (req, res) {
    var transaction = req.body;

    transactionService.createFlightTransaction(transaction)
        .then(function(created_transaction){
            console.log(created_transaction);
            res.json(200, created_transaction);
        })
        .otherwise(function(err){
           handleError(res, err);
        });
};

exports.search_db = function (req, res) {
    var tail_no = req.params.id;

    transactionService.searchFlightHistoryByTailNo(tail_no)
        .then(function(result){
            console.log(result);
            res.json(200, result);
        })
        .otherwise(function(err){
           handleError(res, err);
        });
};

exports.search = function (req, res) {
    var tail_no = req.params.id;

    transactionService.searchFlightHistoryByTailNo(tail_no)
        .then(function(created_transaction){
            res.json(200, created_transaction);
        })
        .otherwise(function(err){
           handleError(res, err);
        });
};

function handleError(res, err) {
    return res.send(500, err);
}
