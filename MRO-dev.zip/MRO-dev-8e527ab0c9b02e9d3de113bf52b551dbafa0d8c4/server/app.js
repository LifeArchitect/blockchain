/**
 * Main application file
 */

'use strict';

// Set default node environment to development
process.env.NODE_ENV = process.env.NODE_ENV || 'development';

var express = require('express');
var mongoose = require('mongoose');
var config = require('./config/environment');
var when = require('when');

// Connect to database
mongoose.connect(config.mongo.uri, config.mongo.options);

// Setup server
var app = express();

var server = require('http').createServer(app);
require('./config/express')(app);
require('./routes')(app);

// gulp-html-extend
var gulp = require('gulp')
//var extender = require('gulp-html-extend')
//var nunjucksRender = require('gulp-nunjucks-render');
 
gulp.task('extend', function () {
    gulp.src('./*.html')
        .pipe(extender({annotations:true,verbose:false})) // default options 
        .pipe(gulp.dest('./output'))
 
})

gulp.task('watch', function () {
    gulp.watch(['./*.html'], ['extend'])
})


try {
// Start server
    server.listen(config.port, config.ip, function () {
        console.log('Express server listening on %d, in %s mode', config.port, app.get('env'));
    });
} catch (e) {
    console.log('Error starting up server: ' + e);
}

// Expose app
exports = module.exports = app;