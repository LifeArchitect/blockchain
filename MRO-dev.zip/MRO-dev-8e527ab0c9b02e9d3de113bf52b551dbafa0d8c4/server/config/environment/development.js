'use strict';

// Development specific configuration
// ==================================
module.exports = {
  // MongoDB connection options
  mongo: {
    uri: 'mongodb://localhost/ramco'
  },
  blockchain: "http://4ce58040.ngrok.io",
  seedDB: false
};
