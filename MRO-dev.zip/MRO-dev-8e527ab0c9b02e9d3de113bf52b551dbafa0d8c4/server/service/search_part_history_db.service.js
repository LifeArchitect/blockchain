var config = require('../config/environment');
var when = require('when');
var mroTransactionDao = require('../dao/mro_transaction.dao');
var _this = this;
var contract_instance;

exports.searchPartHistoryById = function searchPartHistoryById(part_id) {
    //console.log(part_id);
    var transactions = mroTransactionDao.findMroTransactionsByIdPromise(part_id);
    console.log(transactions);
   return when(transactions);
     
};
