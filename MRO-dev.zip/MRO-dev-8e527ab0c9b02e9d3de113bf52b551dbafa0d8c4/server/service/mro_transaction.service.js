/**
 * Service layer for agents
 */
'use strict';

var _ = require('lodash');
var when = require('when');

// var manufactureTransactionDao = require('../dao/manufacture_transaction.dao');

var _this = this;

// Import libraries we need.
var Web3 = require('web3');
var contract = require('truffle-contract');

// Decode the blockchain hash into input params
const InputDataDecoder = require('ethereum-input-data-decoder');

var supply_artifacts = require('../contracts/Supply.json');
var Supply = contract(supply_artifacts);
// abi definition necessary for the decoding
var supply_abi = supply_artifacts.abi;

const decoder = new InputDataDecoder(supply_abi);
var config = require('../config/environment');
var mroTransactionDao = require('../dao/mro_transaction.dao');

var web3 = new Web3(new Web3.providers.HttpProvider(config.blockchain));

var contract_instance;
Supply.setProvider(web3.currentProvider);
Supply.deployed().then(function (contractInstance) {
    contract_instance = contractInstance;
});

exports.createMROTransaction = function(transaction) {
    var defer = when.defer();
    console.log(transaction);
    var date = Date.now().toString();
    var serialNo = transaction.serialNo;
    var personel = transaction.personel;
    var control = transaction.control;

    switch(control) {
    case "Overhaul":
        contract_instance.overhaul(serialNo, personel, date, {gas: 1400000, from: web3.eth.accounts[0]}).then(function (trans) {
            contract_instance.addPartHistory(serialNo, trans.tx, {gas: 140000, from: web3.eth.accounts[0]});
            defer.resolve();

            console.log("adding to MongoDB...");
            mroTransactionDao.createMroTransactionPromise(transaction);
            console.log("Successfully saved to MongoDB...");

        }, function(err) {
            defer.reject(err);
        });
        break;
    case "Remove":
        contract_instance.remove(serialNo, personel, date, {gas: 1400000, from: web3.eth.accounts[0]}).then(function (trans) {
            contract_instance.addPartHistory(serialNo, trans.tx, {gas: 140000, from: web3.eth.accounts[0]});
            defer.resolve();

            console.log("adding to MongoDB...");
            mroTransactionDao.createMroTransactionPromise(transaction);
            console.log("Successfully saved to MongoDB...");

        }, function(err) {
            defer.reject(err);
        });
      break;
    case "Repair":
        contract_instance.repair(serialNo, personel, date, {gas: 1400000, from: web3.eth.accounts[0]}).then(function (trans) {
            contract_instance.addPartHistory(serialNo, trans.tx, {gas: 140000, from: web3.eth.accounts[0]});
            defer.resolve();

            console.log("adding to MongoDB...");
            mroTransactionDao.createMroTransactionPromise(transaction);
            console.log("Successfully saved to MongoDB...");

        }, function(err) {
            defer.reject(err);
        });
        break;
    case "Inspect":
        contract_instance.inspect(serialNo, personel, date, {gas: 1400000, from: web3.eth.accounts[0]}).then(function (trans) {
            contract_instance.addPartHistory(serialNo, trans.tx, {gas: 140000, from: web3.eth.accounts[0]});
            defer.resolve();

            console.log("adding to MongoDB...");
            mroTransactionDao.createMroTransactionPromise(transaction);
            console.log("Successfully saved to MongoDB...");
            
        }, function(err) {
            defer.reject(err);
        });
        break;
    default:
        defer.resolve();
        break;
    }
    return defer.promise;
}
