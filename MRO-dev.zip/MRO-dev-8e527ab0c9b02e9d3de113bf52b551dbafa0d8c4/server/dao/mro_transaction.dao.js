'use strict';

var mongoose = require('mongoose');
var _ = require('lodash');

var MroTransaction = require('./../models/mro_transaction.model.js');

var _this = this;

exports.findMroTransactionsPromise = function () {
    return MroTransaction.find().exec();
}

exports.findMroTransactionsByIdPromise = function (id) {
    console.log("getting promise...");
    console.log(id);
    var transactions = MroTransaction.find({serialNo:id}).exec();
    console.log(transactions);
    return transactions;
}

exports.createMroTransactionPromise = function (mro_transaction) {
    return MroTransaction.create(mro_transaction);
};
