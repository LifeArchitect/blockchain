'use strict';

var express = require('express');
var controller = require('./search_part_history_db.controller');

var router = express.Router();

router.get('/:id', controller.searchPartHistoryDb);

module.exports = router;