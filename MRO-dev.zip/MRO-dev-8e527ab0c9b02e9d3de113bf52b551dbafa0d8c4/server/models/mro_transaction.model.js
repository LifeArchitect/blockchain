'use strict';

var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

var MroTransactionSchema = new Schema({
    serialNo: Number,
    personel: String,
    control: String,
    date: Date
});

module.exports = mongoose.model('MroTransaction', MroTransactionSchema);
