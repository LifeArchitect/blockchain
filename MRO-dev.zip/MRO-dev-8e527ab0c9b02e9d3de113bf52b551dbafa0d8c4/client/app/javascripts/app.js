// Import the page's CSS. Webpack will know what to do with it.
import '../stylesheets/app.css';
// Import libraries we need.

window.mro_action = function() {
  var serialNo = $("#serialNo_MRO").val();
  var personel = $("#actor_MRO").val();
  var control = $("#mro-control").val();
  var date = Date.now().toString();
  $.post("/api/mro/", 
  {
    "serialNo": parseInt(serialNo),
    "personel": personel,
    "control": control,
    "date": date
  });
}

window.search_part_history = function() {
  var id = $("#partIDsearch").val();
  var table = $("#partHistory");
  table.html("<thead class=\"thead-default\"><th>Blockchain Transactions</th></thead><tbody>");
  
  $.get("/api/search/"+id, function(result) {

    if (!result == []){
      
    };
    result.forEach(function(transaction) {
      var row = "<tr>";
      row += "<td><p><strong>HASH:</strong> " + transaction.hash + "</p>";
      row += "<p><strong>Description:</strong> " + transaction.description + "</p>";
      row += "<p><strong>Time of transaction:</strong> " + transaction.time + "</p>";
      row += "</td></tr>";
      table.append(row);
    });
  });
  table.append("</tbody>");
}

window.search_part_history_db = function() {
  var id = $("#partIDsearchDb").val();
  var table = $("#partHistoryDb");
  table.html("<thead class=\"thead-default\"><th>DataBase Transactions</th></thead><tbody>");
  
  $.get("/api/db/search/"+id, function(result) {
    console.log(result);
    result.forEach(function(transaction) {
      var row = "<tr>";
      row += "<td><p><strong>Transaction Type:</strong> " + transaction.control + "</p>";
      row += "<p><strong>SerialNo:</strong> " + transaction.serialNo + "</p>";
      row += "<p><strong>Personel:</strong> " + transaction.personel + "</p>";
      row += "<p><strong>Date:</strong> " + transaction.date + "</p>";
      row += "</td></tr>";
      table.append(row);
    });
  });
  table.append("</tbody>");
}
/* The user enters the total no. of tokens to buy. We calculate the total cost and send it in
 * the request. We have to send the value in Wei. So, we use the toWei helper method to convert
 * from Ether to Wei.
 */

$( document ).ready(function() {

});
