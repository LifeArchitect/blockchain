declare var require: any;
import { Component, OnInit, trigger, state, style, transition, animate } from '@angular/core';
var initDemo = require ('../../../assets/js/charts.js');
import * as $ from 'jquery';
declare var Window: any;

@Component({
    selector: 'home-cmp',
    moduleId: module.id,
    templateUrl: 'home.component.html'
})

export class HomeComponent implements OnInit{
    ngOnInit(){
        // $('[data-toggle="checkbox"]').each(function () {
        //     if($(this).data('toggle') == 'switch') return;
        //
        //     var $checkbox = $(this);
        //     $checkbox.checkbox();
        // });
        initDemo();

    (<any>window).manufacture = function() {
        var date = Date.now().toString();
        var partNo = $("#partNo_M").val();
        var serialNo = $("#serialNo_M").val();;
        var description = $("#description_M").val();
        var owner = $("#manufacturer").val();
        var cost = $("#cost").val();

        $.post("/api/manufacture/", 
        {
            "partNo": parseInt(partNo),
            "serialNo": parseInt(serialNo),
            "description": description,
            "owner": owner,
            "cost": cost
        });
     }

/*
     (<any>window).search_part_history = function() {
        var date = Date.now().toString();
        var id = $("#partIDsearch").val();
        var table = $("#partHistory");
        table.html("<thead class=\"thead-default\"><th>Transactions</th></thead><tbody>");
  
        $.get("/api/search/"+id, function(result) {
            result.forEach(function(transaction) {
            var row = "<tr>";
            row += "<td><p><strong>HASH:</strong> " + transaction.hash + "</p>";
            row += "<p><strong>Description:</strong> " + transaction.description + "</p>";
            row += "<p><strong>Time of transaction:</strong> " + transaction.time + "</p>";
            row += "</td></tr>";
            table.append(row);
            });
         });
        table.append("</tbody>");
    }

    */
    
    }
}
