declare module "*.json" {
    const value: any;
    export default value;

    interface Window {
      manufacture: any;
      search_part_hitsory: any;
    }

}
