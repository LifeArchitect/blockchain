"use strict";
//# sourceMappingURL=sidebar.metadata.js.map