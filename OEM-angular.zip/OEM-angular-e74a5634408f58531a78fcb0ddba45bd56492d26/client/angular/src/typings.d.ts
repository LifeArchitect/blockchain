/* SystemJS module definition */
declare var module: NodeModule;
interface NodeModule {
  id: string;
}

interface Window {
      manufacture: any;
      search_part_history: any;
    }
