'use strict';

// Development specific configuration
// ==================================
module.exports = {
  // MongoDB connection options
  mongo: {
    uri: 'mongodb://localhost/ramco'
  },
  blockchain: "http://b532051b.ngrok.io",
  seedDB: false
};
